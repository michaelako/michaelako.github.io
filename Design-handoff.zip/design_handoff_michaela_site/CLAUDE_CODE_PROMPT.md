# Kickoff prompt (paste into your coding assistant)

I'm building my personal site. In this folder is a **design prototype in HTML** (`Michaela Kotarba.dc.html`) plus `README.md`, which specifies every color, type, spacing and motion value, and `MOBILE_AND_STACK.md`, which has the recommended stack and the mobile plan.

Please:

1. Read `README.md` first, then open the prototype in a browser and interact with it (toggle 5–9 / 9–5, click through both card stacks) so you understand the motion before writing code.
2. Scaffold a **Next.js (App Router) + TypeScript + Tailwind v4** project. Define the two themes as CSS variables on `:root` and `html[data-theme="dark"]` using the exact token names and values in the README.
3. Build desktop first, matching the prototype pixel-for-pixel at 1440px wide: header + toggle, hero, photo card stack (5–9), about + Spotify embed, text card stack (9–5), writing list, contact.
4. Port the cloud-canvas background verbatim from the prototype's logic (7 blobs, the listed sine drifts, 0.5× backing store, `blur(54px)`). **No mouse interaction** — it must drift on its own only.
5. Then implement the mobile plan in `MOBILE_AND_STACK.md` (900px breakpoint, card stack becomes a vertical accordion driven by height, `dvh` units, reduced-motion handling).
6. Use placeholder `<Image>` components for the four photos and `#` hrefs for the three writing links; keep the lorem ipsum copy but centralize it in one `content.ts` so I can swap in real text.
7. Persist the theme in `localStorage`, seed it from `prefers-color-scheme`, and set `data-theme` before first paint so there's no flash.

Constraints: no UI kit, no animation library unless you can justify it; every color and spacing value must come from the CSS variables; keep the two card stacks' active indices independent; accessible focus rings on the toggle, cards and links (2px accent outline, 2px offset) and `aria-pressed` on the toggle buttons.

When desktop is done, stop and show me before starting mobile.
