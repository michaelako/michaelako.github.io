# Handoff: michaelakotarba.com — personal site (5–9 / 9–5)

## Overview
A one-page personal site for Michaela Kotarba with two personas behind one layout, switched by a toggle in the header:

- **5–9 (light)** — the yoga/movement side: photo card-stack, about me, Spotify playlist.
- **9–5 (dark)** — the product/tech side: text card-stack (Product / SWE / Research / Education) and a writing list.

Both modes share the same hero, the same animated cloud-gradient background, and the same contact section. Nothing else on the page changes between modes.

## About the design files
The files in this bundle are **design references authored in HTML** — a working prototype of the intended look, motion, and behavior. They are **not production code to copy**. The task is to recreate this design in the target codebase using its own framework and conventions. If there is no codebase yet, pick a framework (recommendation below) and build it there.

`Michaela Kotarba.dc.html` is the source of truth for every value in this README. Open it in a browser to see the motion.

## Fidelity
**High-fidelity.** Colors, type, spacing, motion curves and durations are final. Recreate them exactly. Content is final except: all body/about/card copy is lorem ipsum placeholder, the four photos are empty drop-slots, and the three writing links are placeholders.

---

## Page structure (both modes)

1. **Header** — brand mark "mk" left, 5–9 / 9–5 segmented toggle right.
2. **Hero** — huge lowercase name + three free-floating italic labels (mode-dependent).
3. **Card stack** — photos in 5–9, text panels in 9–5.
4. **5–9 only:** About me (3 paragraphs) + Spotify playlist embed, two columns.
5. **9–5 only:** Writing list, 3 rows.
6. **Contact** — "open to opportunities" + say hello button.

Page padding, every section: `clamp(24px, 5vw, 72px)` horizontal.

---

## Screens / views

### Header
- Flex row, `justify-content: space-between`, padding `28px [page-x] 0`.
- Brand: "mk", Newsreader italic 17px, `--ink-soft`.
- Toggle: pill container — `padding 4px`, `border-radius 999px`, `background var(--toggle-shell)`, `1px solid var(--hairline)`; two buttons, `padding 8px 18px`, `border-radius 999px`, Karla 12px, `letter-spacing .12em`, labels `5–9` and `9–5` (en dashes). Active button: `background var(--toggle-*-bg)` (near-opaque white in its own mode), inactive is transparent with `--toggle-*-ink`.
- The toggle sets `document.documentElement.dataset.theme = 'light' | 'dark'`; everything else follows from CSS variables. Default is light (5–9).

### Hero
- Section padding: `clamp(70px,13vh,150px)` top, `clamp(80px,14vh,170px)` bottom.
- `h1`: "michaela kotarba" — Newsreader 600, `font-size: clamp(58px, 12.5vw, 210px)`, `line-height: .88`, `letter-spacing: -.045em`, `text-transform: lowercase`, `max-width: 12ch`, color `--ink`, left aligned.
- Floating labels: a relative box `height: clamp(128px,17vh,190px)`, `margin-top: clamp(16px,2.6vh,30px)`; three absolutely positioned spans, all identical in type — Newsreader **italic 400**, `clamp(24px, 3.2vw, 42px)` — differing only in purple and position:
  | slot | position | color (light) | color (dark) | animation |
  | --- | --- | --- | --- | --- |
  | 1 | left 2%, top 0% | `--float-1` #5c4080 | #d3bfe8 | driftA 11s |
  | 2 | left 34%, top 36% | `--float-2` #7b5c9e | #b49ad2 | driftB 14s |
  | 3 | left 11%, top 70% | `--float-3` #74569f | #9782bd | driftC 17s |
- Text per mode — light: `yoga instructor` / `Raleigh, NC` / `studio fitness`; dark: `product manager` / `Raleigh, NC` / `ex-SWE`.
- Drift keyframes, all `ease-in-out infinite alternate`:
  - driftA: `translate3d(0,0,0) rotate(-1.5deg)` → `translate3d(14px,-22px,0) rotate(1deg)`
  - driftB: `translate3d(0,0,0) rotate(1deg)` → `translate3d(-20px,16px,0) rotate(-1.5deg)`
  - driftC: `translate3d(0,0,0) rotate(-.5deg)` → `translate3d(18px,18px,0) rotate(2deg)`

### Card stack (the signature interaction)
One row of 4 cards; exactly one is expanded and fills nearly the whole viewport width, the rest are collapsed slivers. Clicking a sliver expands it — cards to its left stay left, cards to its right stay right, so walking through 1→4 slides the stack leftward until the last card is expanded with three slivers stacked to its left.

- Row: `display:flex; align-items:stretch; gap:14px`; height `min(82vh, 860px)` (photos) / `min(78vh, 820px)` (text).
- Card: `position:relative; flex-basis:0; min-width:112px; border-radius:26px; overflow:hidden; cursor:pointer`, `background var(--card-frame)`, `box-shadow var(--card-shadow)`; text cards additionally `1px solid var(--hairline)`.
- Expanded vs collapsed is driven by `flex-grow`: **26** expanded, **1** collapsed.
- Transition: `flex-grow 760ms cubic-bezier(.22,.82,.24,1), filter 760ms ease`.
- Collapsed cards: `filter: saturate(.82) brightness(.94)` (photos) / `brightness(.94)` (text). Expanded: no filter.
- Caption: Newsreader italic 25px, `padding: 24px 22px`, anchored bottom-left, `pointer-events:none`. Photo captions are `#fdfbff` with `text-shadow: 0 2px 16px rgba(30,16,44,.55)`; text-card captions use `--ink`.
  - Expanded: `writing-mode: horizontal-tb`, no transform.
  - Collapsed: `writing-mode: vertical-rl; transform: rotate(180deg)` — the label reads bottom-to-top up the sliver. This is required: a horizontal caption clips inside a 112px sliver.
- **Photo cards (5–9)**: captions `community`, `studio`, `privates`, `groups`. The image fills an inner wrapper that is `width:100%` when expanded and `min(620px, 62vw)` when collapsed, absolutely positioned at `left:0` — so a sliver shows the photo's left edge rather than a squeezed image.
- **Text cards (9–5)**: captions `Product`, `SWE`, `Research`, `Education`. Body panel is absolutely inset, `padding: clamp(30px,3.2vw,54px)` with `96px` bottom (clears the caption), two paragraphs at 17px/1.78 `--ink-soft`, `max-width:58ch`; `opacity: 1` when expanded, `0` when collapsed, `transition: opacity 460ms ease`.
- The two stacks keep **independent** active indices (state `active` for photos, `work` for text), both default 0.

### About me + playlist (5–9 only)
- Grid: `minmax(0,1.35fr) minmax(300px,.65fr)`, `gap: clamp(32px,5vw,80px)`, `align-items:start`, `max-width:1280px`.
- Left: kicker "About me" (12px, `letter-spacing .2em`, uppercase, `--ink-faint`) + 3 paragraphs, 17px/1.8, `--ink-soft`, `max-width:60ch`, `text-wrap:pretty`, `gap:18px`.
- Right: kicker "On repeat" + Spotify iframe, `width:100%`, `height:352`, `border-radius:12px`, `loading="lazy"`, playlist `2lfLw4ho5fyW0bekAb8qIy`:
  `https://open.spotify.com/embed/playlist/2lfLw4ho5fyW0bekAb8qIy?utm_source=generator`

### Writing (9–5 only)
- Kicker "Writing", then 3 `<a>` rows: flex, `justify-content:space-between`, `align-items:baseline`, `padding:22px 4px`, `border-top:1px solid var(--hairline)` (last row also `border-bottom`), `max-width:900px`.
- Row title: Newsreader `clamp(22px,2.6vw,32px)`, `--ink`; hover `--float-2`. Right side: year, 12px, `letter-spacing .14em`, uppercase, `--ink-faint`. Titles/links are placeholders (`#`).

### Contact
- Kicker "Practice with me"; `h2` "open to opportunities" — Newsreader 600, `clamp(34px,5vw,62px)`, `line-height 1.06`, `letter-spacing -.03em`, lowercase.
- Button: `mailto:michaelakotarba@gmail.com`, label "say hello" — background `--wisteria`, color `--cta-ink`, Karla 700 14px, `letter-spacing .04em`, `border-radius 999px`, `padding 15px 30px`; hover background `--float-2`.
- Beside it: "studio classes, pop-ups, and private sessions" — Newsreader italic 18px, `--ink-soft`.

---

## Background: gradient + drifting clouds
Two fixed full-viewport layers behind all content (`z-index` 0 and 1; content is 3):

**1. Static CSS gradient** (`--page-gradient`), light:
```css
radial-gradient(1100px 820px at 86% 4%, rgba(244,206,214,.85) 0%, rgba(244,206,214,0) 58%),
radial-gradient(1000px 860px at 4% 96%, rgba(168,136,214,.8) 0%, rgba(168,136,214,0) 60%),
radial-gradient(900px 700px at 50% 46%, rgba(226,208,246,.7) 0%, rgba(226,208,246,0) 62%),
linear-gradient(154deg, #fdf9fc 0%, #eee3f6 26%, #d5c0ea 58%, #b79ad8 82%, #a184cc 100%)
```
dark:
```css
radial-gradient(1100px 820px at 86% 4%, rgba(140,96,132,.75) 0%, rgba(140,96,132,0) 58%),
radial-gradient(1000px 860px at 4% 96%, rgba(96,68,148,.85) 0%, rgba(96,68,148,0) 60%),
radial-gradient(900px 700px at 50% 46%, rgba(74,54,104,.7) 0%, rgba(74,54,104,0) 62%),
linear-gradient(154deg, #120c18 0%, #1e1527 26%, #33244c 58%, #452f68 84%, #543a7a 100%)
```

**2. Cloud canvas** — `<canvas>` fixed inset 0, `filter: blur(54px)`, `pointer-events:none`. **No mouse interaction** (an earlier pointer-trail version was removed deliberately — do not reintroduce it).
- Backing store is deliberately small: `width/height = viewport * min(dpr,2) * 0.5`, re-set on resize. The 54px blur hides the low resolution and keeps it cheap.
- 7 ellipse blobs, each `{bx, by, r, ar, sp, ph, c}` (base position as fraction of canvas, radius as fraction of `min(w,h)`, y-scale, speed, phase, palette index):
```js
{bx:.18,by:.22,r:.40,ar:.72,sp:.045,ph:0.4,c:0}
{bx:.74,by:.16,r:.36,ar:.85,sp:.033,ph:2.1,c:1}
{bx:.52,by:.58,r:.46,ar:.62,sp:.027,ph:3.6,c:2}
{bx:.12,by:.78,r:.38,ar:.80,sp:.038,ph:1.2,c:3}
{bx:.88,by:.70,r:.42,ar:.70,sp:.031,ph:5.0,c:0}
{bx:.36,by:.05,r:.30,ar:.90,sp:.052,ph:4.2,c:4}
{bx:.66,by:.92,r:.34,ar:.75,sp:.041,ph:0.9,c:2}
```
- Per frame (`t` = seconds): `clearRect`, then for each blob
  `x = (bx + .055*sin(t*sp*6.28+ph) + .032*sin(t*sp*3.4+ph*1.7)) * w`,
  `y = (by + .045*sin(t*sp*5.1+ph*2.3) + .028*cos(t*sp*2.6+ph)) * h`,
  `r = r * min(w,h) * (1 + .07*sin(t*sp*4.2+ph))`,
  rotate `.4*sin(t*sp*2+ph)`, `scale(1, ar)`, fill a 3-stop radial gradient (`alpha`, `alpha*.45` at 55%, `0` at edge).
- Palettes / base alphas — light: `rgba(206,178,238)` .72, `rgba(248,214,218)` .60, `rgba(178,150,222)` .60, `rgba(255,252,255)` .66, `rgba(196,214,240)` .46. Dark: `rgba(96,70,126)` .66, `rgba(132,90,146)` .54, `rgba(58,42,88)` .62, `rgba(160,126,186)` .36, `rgba(70,58,124)` .50.
- Motion is very slow and self-running — a full wander cycle is ~25–40s. It should read as breathing, never as animation.

---

## State
- `theme: 'light' | 'dark'` — set on `<html data-theme>`; persist in `localStorage` and honor `prefers-color-scheme` on first visit (the prototype defaults to light).
- `activePhoto: 0..3`, `activeWork: 0..3` — independent.
- No data fetching. Photos are static assets; the playlist is an iframe.

## Design tokens

| token | light | dark |
| --- | --- | --- |
| body bg (behind gradient) | #ece1f4 | — |
| `--ink` | #2a1c30 | #f4ecf5 |
| `--ink-soft` | #5a4a5f | #cabbd0 |
| `--ink-faint` | #6f5f77 | #a191a9 |
| `--hairline` | rgba(42,28,48,.16) | rgba(244,236,245,.18) |
| `--wisteria` (accent) | #6b4f8a | #c1a6d8 |
| `--cta-ink` | #fdfbff | #241a2c |
| `--float-1/2/3` | #5c4080 / #7b5c9e / #74569f | #d3bfe8 / #b49ad2 / #9782bd |
| `--card-frame` | rgba(255,255,255,.72) | rgba(255,255,255,.14) |
| `--card-shadow` | 0 26px 60px rgba(58,36,86,.24) | 0 26px 60px rgba(8,4,16,.5) |
| `--toggle-shell` | rgba(42,28,48,.06) | rgba(244,236,245,.09) |
| active toggle bg | rgba(255,255,255,.9) | rgba(244,236,245,.9) |

- **Type**: Newsreader (300/400/600 + italics) for display, headings, captions and quotes; Karla (400/500/700) for interface text, kickers and buttons. Google Fonts.
- **Radii**: cards 26px, iframe 12px, pills 999px.
- **Motion**: 760ms `cubic-bezier(.22,.82,.24,1)` for card expansion, 460ms ease for panel opacity, 11–17s alternating drifts for floating labels.

## Assets
- 4 photographs for the 5–9 stack (**not yet supplied** — the prototype uses empty drop slots via the bundled `image-slot.js`; replace with real `<img>`/`next/image`). Portrait-friendly crops: a sliver shows the image's left edge.
- No icons. No logo file — "mk" is set type.
- Fonts from Google Fonts; nothing else external except the Spotify embed.

## Files in this bundle
- `Michaela Kotarba.dc.html` — the design prototype (open in a browser; it is self-contained apart from the two files below).
- `image-slot.js` — the placeholder-image component used by the prototype. Prototype-only; drop it in the rebuild.
- `organic-styles.css` — the design-system stylesheet the prototype links (token reference only; the page's own tokens above take precedence).
- `CLAUDE_CODE_PROMPT.md` — a ready-to-paste kickoff prompt.
