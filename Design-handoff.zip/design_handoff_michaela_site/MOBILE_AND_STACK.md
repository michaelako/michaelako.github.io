# Recommended build + mobile plan

## Stack recommendation
- **Next.js (App Router) + TypeScript + Tailwind v4**, deployed on Vercel. Static, fast, and the two themes map cleanly onto CSS variables in `@theme`/`:root` + `html[data-theme="dark"]` — exactly how the prototype works, so token names can carry over 1:1.
- **No animation library needed.** The card stack is a `flex-grow` transition; the floating labels are CSS keyframes. Add Motion (framer-motion) only if you want the cards to animate with layout projection instead — it is not required for parity.
- The cloud background is one `"use client"` component: a `<canvas>` + `requestAnimationFrame` loop, ported verbatim from the prototype. Keep the 0.5× backing store and the 54px blur.
- Images: `next/image` with `fill` + `object-fit: cover`, `sizes` reflecting expanded vs collapsed widths, and `priority` on the first card only.
- Theme: set `data-theme` on `<html>` from a tiny inline script before paint (avoids a flash), persist in `localStorage`, seed from `prefers-color-scheme`.
- Alternatives that would also be fine: Astro + vanilla CSS (least JS, ideal for a personal site), or Vite + React if you don't want a framework's conventions.

## Mobile plan (the one part the desktop design doesn't answer)
Breakpoint at **900px**. Above it, build exactly what the prototype shows. Below it:

1. **Card stack → vertical accordion.** Same mechanic, rotated: the row becomes `flex-direction: column`, height becomes `auto`, and `flex-grow` drives *height* instead of width — expanded card `min-height: 62vh`, collapsed rows `88px` tall. Collapsed captions go back to `writing-mode: horizontal-tb` (no rotation) since a short row is wide, not narrow. Keep the 760ms curve. Tap targets are then ~88px — well past the 44px minimum.
2. **Hero.** `h1` at `clamp(44px, 15vw, 96px)`; keep lowercase and `-.045em`. The three floating labels stop being absolutely positioned — make them a `flex` column with `gap: 14px` and per-item `margin-left` of 0 / 18% / 8% to keep the scattered feel, at `clamp(20px, 6.5vw, 30px)`. Keep the drift animations but halve the translate distances.
3. **About + playlist** collapse to one column, playlist below the text, iframe `height: 152` (Spotify's compact size) under 480px.
4. **Writing rows** stay full-width; stack year under title if it wraps.
5. **Header** stays a single row; the toggle is the only control, so give both buttons `min-height: 44px`.
6. **Background performance.** On phones drop the cloud canvas to 5 blobs and a 0.35× backing store, or swap it for 3 CSS-animated blurred `div`s — the visual difference at that size is negligible and it saves the battery. Honor `@media (prefers-reduced-motion: reduce)`: freeze the clouds on a single rendered frame, stop the label drifts, and shorten the card transition to 200ms.
7. **Viewport units.** Use `dvh`, not `vh`, for anything full-height so mobile browser chrome doesn't clip the hero or the expanded card.
8. **Test matrix:** 390×844 (iPhone), 414×896, 768 (tablet portrait — still accordion), 1024, 1440, 1920.

## How to get the best results from a coding assistant
1. **Hand over this whole folder**, not screenshots. The HTML prototype is the spec: the assistant can open it, read computed styles, and diff its own build against it.
2. **Paste `CLAUDE_CODE_PROMPT.md` as the first message**, with the folder in the working directory.
3. **Ask for desktop parity first**, then mobile. Reviewing one axis at a time catches drift early.
4. **Insist on tokens, not literals**: every color/spacing value should reference the CSS variables in the README table, so retheming later is one file.
5. **Give it the real content early** — the four photos and the three writing links. Lorem ipsum hides layout problems (line lengths, wrap points) that only appear with real copy.
6. **Ask for a side-by-side check**: run the prototype and the build at 1440px and 390px and compare type sizes, card widths, and the 760ms easing.
